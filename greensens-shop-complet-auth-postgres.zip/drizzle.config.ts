import { defineConfig } from "drizzle-kit";

const connectionString = process.env.PG_DATABASE_URL;
if (!connectionString) {
  throw new Error("PG_DATABASE_URL is required to run drizzle commands");
}

export default defineConfig({
  schema: "./drizzle/schema.ts",
  out: "./drizzle",
  dialect: "postgresql",
  dbCredentials: { url: connectionString },
});
